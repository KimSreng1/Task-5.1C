import React from 'react';
import { Menu, Input, Button } from 'semantic-ui-react';
import { Link, useLocation } from 'react-router-dom';

export default function Header() {
  const { pathname } = useLocation();

  return (
    <Menu borderless>
      {/* Brand -> Home */}
      <Menu.Item
        as={Link}
        to="/"
        header
        active={pathname === '/'}
      >
        DEV@Deakin
      </Menu.Item>

      {/* Search */}
      <Menu.Item>
        <Input icon="search" placeholder="Search…" aria-label="Search" />
      </Menu.Item>

      {/* Right side */}
      <Menu.Menu position="right">
        <Menu.Item>
          <Button
            as={Link}
            to="/post"
            basic
            active={pathname === '/post'}
          >
            Post
          </Button>
        </Menu.Item>
        <Menu.Item>
          <Button
            as={Link}
            to="/login"
            primary
            active={pathname === '/login'}
          >
            Login
          </Button>
        </Menu.Item>
      </Menu.Menu>
    </Menu>
  );
}
