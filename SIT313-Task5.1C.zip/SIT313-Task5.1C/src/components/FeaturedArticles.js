import React from 'react';
import { Card, Image, Icon, Button, Header } from 'semantic-ui-react';
import { faker } from '@faker-js/faker';

const articles = Array.from({ length: 4 }).map(() => ({
  title: faker.lorem.words(3),
  description: faker.lorem.sentence(),
  author: faker.name.firstName(),
  image: `https://picsum.photos/200/150?random=${Math.random() * 1000}`
}));

export default function FeaturedArticles() {
  return (
    <div style={{ padding: '2em' }}>
      <Header as='h2' textAlign='center'>Featured Articles</Header>
      <Card.Group itemsPerRow={4} stackable>
        {articles.map((a, i) => (
          <Card key={i}>
            <Image src={a.image} />
            <Card.Content>
              <Card.Header>{a.title}</Card.Header>
              <Card.Description>{a.description}</Card.Description>
            </Card.Content>
            <Card.Content extra>
              <Icon name='star' color='yellow' /> 5 &nbsp; {a.author}
            </Card.Content>
          </Card>
        ))}
      </Card.Group>
      <div style={{ textAlign: 'center', marginTop: '1em' }}>
        <Button>See all articles</Button>
      </div>
    </div>
  );
}
