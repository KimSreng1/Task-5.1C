import React from 'react';
import { Grid, Segment, List, Header, Icon } from 'semantic-ui-react';

export default function Footer() {
  return (
    <Segment inverted style={{ padding: '4em 0em' }}>
      <Grid divided inverted stackable>
        <Grid.Row>
          <Grid.Column width={4}>
            <Header inverted>Explore</Header>
            <List link inverted>
              <List.Item>Home</List.Item>
              <List.Item>Questions</List.Item>
              <List.Item>Articles</List.Item>
              <List.Item>Tutorials</List.Item>
            </List>
          </Grid.Column>
          <Grid.Column width={4}>
            <Header inverted>Support</Header>
            <List link inverted>
              <List.Item>FAQs</List.Item>
              <List.Item>Help</List.Item>
              <List.Item>Contact Us</List.Item>
            </List>
          </Grid.Column>
          <Grid.Column width={4}>
            <Header inverted>Stay connected</Header>
            <List horizontal>
              <List.Item icon={<Icon name='facebook' />} />
              <List.Item icon={<Icon name='twitter' />} />
              <List.Item icon={<Icon name='instagram' />} />
            </List>
          </Grid.Column>
        </Grid.Row>
      </Grid>
      <div style={{ textAlign: 'center', marginTop: '1em' }}>
        DEV@Deakin 2022 – Privacy Policy | Terms | Code of Conduct
      </div>
    </Segment>
  );
}
