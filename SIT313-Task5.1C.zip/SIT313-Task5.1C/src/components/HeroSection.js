import React from 'react';
import { Segment, Image } from 'semantic-ui-react';

export default function HeroSection() {
  return (
    <Segment basic style={{ padding: 0 }}>
      <Image
        src='https://picsum.photos/1200/300?grayscale&blur=1'
        fluid
        centered
        alt="Banner"
      />
    </Segment>
  );
}
