import React, { useState } from 'react';
import { Form, Label, Input } from 'semantic-ui-react';

export default function TagInput({ value = [], onChange }) {
  const [input, setInput] = useState('');

  const addTag = (e) => {
    e.preventDefault();
    const t = input.trim();
    if (!t) return;
    if (value.includes(t)) return;
    onChange([...(value || []), t]);
    setInput('');
  };

  const removeTag = (t) => {
    onChange(value.filter((x) => x !== t));
  };

  return (
    <>
      <Form onSubmit={addTag}>
        <Form.Field>
          <label>Tags</label>
          <Input
            placeholder="Press Enter to add a tag"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
        </Form.Field>
      </Form>
      <div style={{ marginTop: 8 }}>
        {(value || []).map((t) => (
          <Label key={t} onClick={() => removeTag(t)} style={{ cursor: 'pointer', marginBottom: 6 }}>
            {t} &times;
          </Label>
        ))}
      </div>
    </>
  );
}
