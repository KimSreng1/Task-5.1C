import React, { useState } from 'react';
import { Container, Header as UIHeader, Segment, Button, Message } from 'semantic-ui-react';
import PostTypeToggle from './PostTypeToggle';
import PostFormQuestion from './PostFormQuestion';
import PostFormArticle from './PostFormArticle';
import PreviewCard from './PreviewCard';

export default function PostPage() {
  const [type, setType] = useState('question'); // 'question' | 'article'
  const [data, setData] = useState({ title: '', body: '', tags: [] });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (partial) => setData((d) => ({ ...d, ...partial }));

  const handleSubmit = () => {
    // No backend in this task. Just show success and preview.
    setSubmitted(true);
  };

  return (
    <Container style={{ maxWidth: 900, marginTop: 24, marginBottom: 48 }}>
      <UIHeader as="h1" content="Create a New Post" subheader="Choose type, fill the form, and preview." />

      <Segment>
        <PostTypeToggle value={type} onChange={setType} />
      </Segment>

      <Segment>
        {type === 'question' ? (
          <PostFormQuestion value={data} onChange={handleChange} onSubmit={handleSubmit} />
        ) : (
          <PostFormArticle value={data} onChange={handleChange} onSubmit={handleSubmit} />
        )}
      </Segment>

      {submitted && (
        <Message positive>
          <Message.Header>Post captured (UI only)</Message.Header>
          <p>This task doesn’t save to a database yet. You can still preview below.</p>
          <Button onClick={() => setSubmitted(false)} content="Edit Again" />
        </Message>
      )}

      <PreviewCard type={type} data={data} />
    </Container>
  );
}
