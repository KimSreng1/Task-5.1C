import React from 'react';
import { Card, Header, Divider } from 'semantic-ui-react';

export default function PreviewCard({ type, data }) {
  const { title, body, tags = [] } = data || {};
  return (
    <Card fluid style={{ marginTop: 24 }}>
      <Card.Content>
        <Header as="h3">Preview ({type})</Header>
        <Divider />
        <Header as="h2" style={{ marginTop: 0 }}>{title || 'Untitled'}</Header>
        <p style={{ whiteSpace: 'pre-wrap' }}>{body || 'Nothing yet...'}</p>
        {tags.length > 0 && (
          <>
            <Divider />
            <div>
              <strong>Tags:</strong> {tags.join(', ')}
            </div>
          </>
        )}
      </Card.Content>
    </Card>
  );
}
