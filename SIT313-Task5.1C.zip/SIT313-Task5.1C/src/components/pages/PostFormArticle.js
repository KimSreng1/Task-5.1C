import React from 'react';
import { Form, Button, TextArea } from 'semantic-ui-react';
import TagInput from './TagInput';

export default function PostFormArticle({ value, onChange, onSubmit }) {
  return (
    <Form onSubmit={onSubmit}>
      <Form.Input
        label="Title"
        placeholder="Article title"
        value={value.title}
        onChange={(e, { value: v }) => onChange({ title: v })}
        required
      />
      <Form.Field
        control={TextArea}
        label="Content"
        placeholder="Write your article..."
        value={value.body}
        onChange={(e, { value: v }) => onChange({ body: v })}
        rows={12}
        required
      />
      <TagInput value={value.tags} onChange={(tags) => onChange({ tags })} />
      <Button primary type="submit" content="Publish (UI only)" style={{ marginTop: 12 }} />
    </Form>
  );
}
