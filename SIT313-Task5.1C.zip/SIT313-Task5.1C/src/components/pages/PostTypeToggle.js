import React from 'react';
import { Form, Radio } from 'semantic-ui-react';

export default function PostTypeToggle({ value, onChange }) {
  return (
    <Form>
      <Form.Field>
        <Radio
          label="Question"
          name="postType"
          value="question"
          checked={value === 'question'}
          onChange={() => onChange('question')}
          style={{ marginRight: 16 }}
        />
        <Radio
          label="Article"
          name="postType"
          value="article"
          checked={value === 'article'}
          onChange={() => onChange('article')}
        />
      </Form.Field>
    </Form>
  );
}
