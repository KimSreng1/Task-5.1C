import React from 'react';
import { Form, Button, TextArea } from 'semantic-ui-react';
import TagInput from './TagInput';

export default function PostFormQuestion({ value, onChange, onSubmit }) {
  return (
    <Form onSubmit={onSubmit}>
      <Form.Input
        label="Title"
        placeholder="What’s your question?"
        value={value.title}
        onChange={(e, { value: v }) => onChange({ title: v })}
        required
      />
      <Form.Field
        control={TextArea}
        label="Details"
        placeholder="Explain the issue, context, and what you tried."
        value={value.body}
        onChange={(e, { value: v }) => onChange({ body: v })}
        rows={8}
        required
      />
      <TagInput value={value.tags} onChange={(tags) => onChange({ tags })} />
      <Button primary type="submit" content="Post Question" style={{ marginTop: 12 }} />
    </Form>
  );
}
