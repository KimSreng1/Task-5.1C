import React from 'react';
import { Segment, Input, Button, Header } from 'semantic-ui-react';

export default function NewsletterSignup() {
  return (
    <Segment textAlign='center' style={{ padding: '2em' }}>
      <Header as='h3'>SIGN UP FOR OUR DAILY INSIDER</Header>
      <Input action={{ content: 'Subscribe' }} placeholder='Enter your email…' />
    </Segment>
  );
}
