// import React from 'react';
// import { Card } from 'semantic-ui-react';
// import { faker } from '@faker-js/faker';


// export default function FeaturedCards() {
//   const articles = Array.from({ length: 4 }).map(() => ({
//     title: faker.lorem.sentence(),
//     description: faker.lorem.paragraph(),
//     image: `https://picsum.photos/200/150?random=${Math.floor(Math.random() * 1000)}`
//   }));

//   return (
//     <Card.Group itemsPerRow={2} stackable style={{ padding: '2em' }}>
//       {articles.map((item, idx) => (
//         <Card
//           key={idx}
//           image={item.image}
//           header={item.title}
//           description={item.description}
//         />
//       ))}
//     </Card.Group>
//   );
// }
