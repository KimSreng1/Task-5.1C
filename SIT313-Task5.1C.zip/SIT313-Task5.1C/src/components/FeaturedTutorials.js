import React from 'react';
import { Card, Image, Icon, Button, Header } from 'semantic-ui-react';
import { faker } from '@faker-js/faker';

const tutorials = Array.from({ length: 3 }).map(() => ({
  title: faker.lorem.words(2),
  description: faker.lorem.sentence(),
  user: faker.internet.userName(),
  rating: (Math.random() * 1 + 4).toFixed(1),
  image: `https://picsum.photos/200/150?random=${Math.random() * 1000}`
}));

export default function FeaturedTutorials() {
  return (
    <div style={{ padding: '2em' }}>
      <Header as='h2' textAlign='center'>Featured Tutorials</Header>
      <Card.Group itemsPerRow={3} stackable>
        {tutorials.map((t, i) => (
          <Card key={i}>
            <Image src={t.image} />
            <Card.Content>
              <Card.Header>{t.title}</Card.Header>
              <Card.Description>{t.description}</Card.Description>
            </Card.Content>
            <Card.Content extra>
              <Icon name='star' color='yellow' /> {t.rating} &nbsp; {t.user}
            </Card.Content>
          </Card>
        ))}
      </Card.Group>
      <div style={{ textAlign: 'center', marginTop: '1em' }}>
        <Button>See all tutorials</Button>
      </div>
    </div>
  );
}
