// src/App.js
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import 'semantic-ui-css/semantic.min.css';

// Shared layout components
import Header from './components/Header';
import Footer from './components/Footer';

// Home page sections
import HeroSection from './components/HeroSection';
import FeaturedArticles from './components/FeaturedArticles';
import FeaturedTutorials from './components/FeaturedTutorials';
import NewsletterSignup from './components/NewsletterSignup';


import PostPage from './components/pages/PostPage';

function Home() {
  return (
    <>
      <HeroSection />
      <FeaturedArticles />
      <FeaturedTutorials />
      <NewsletterSignup />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/post" element={<PostPage />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  );
}
